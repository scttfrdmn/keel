keel-gvt2 /var/folders/nn/qc8dm2b954jbyvcwk0v79ync0000gn/T/tmp.wmU2fWDQ1W/bench.test -test.run=NONE -test.count=10 -test.benchtime=1s -test.bench=(Peak|Sgemm|OpenBLAS)/(neon|n=2048)
