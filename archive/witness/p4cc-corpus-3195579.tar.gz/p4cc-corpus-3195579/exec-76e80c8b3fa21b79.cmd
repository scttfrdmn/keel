vesta.local /var/folders/nn/qc8dm2b954jbyvcwk0v79ync0000gn/T/tmp.O32GLjGytM/kern.test -test.run=NONE -test.count=10 -test.benchtime=1s -test.bench=Peak|Kernel/.*/.*/kc=128
